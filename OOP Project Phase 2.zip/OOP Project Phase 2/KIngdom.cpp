#include "Kingdom.h"
#include <iostream>
using namespace std;
#include <cstdlib> // For rand()

Kingdom::Kingdom() : bank(economy), leader("King Arthur", "King", false), dayCount(0) {
    gold = 1000;
    food = 500;
    populations = 200;
    isGameOver = false;
    messageCount = 0;

    self.name = "YourKingdom";
    self.x = 2;
    self.y = 2;
    initializeMap();


}

void Kingdom::runSimulation() {
    while (true) {
        cout << endl<<"=== Day " << dayCount << " ===" << endl;
        displayStatus();
        displayMap();
        showMenu();

        int choice;
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 0) break;
        handleChoice(choice);
        updateGameState();
        dayCount++;
    }
}

void Kingdom::showMenu() {
    cout << endl << "Kingdom Management Menu:"<< endl ;
    cout << "1. Collect Taxes"<< endl;
    cout << "2. Recruit Soldiers" << endl;
    cout << "3. Train Army" << endl;
    cout << "4. Train Army" << endl;
    cout << "5. Request Bank Loan" << endl;
    cout << "6. Manage Resources" << endl;
    cout << "7. Handle Social Issues" << endl;
    cout << "8. Pass Day" << endl;
    cout << "9.Random Event Generate" << endl;
    cout << "10. Move Kingdom" << endl;
    cout << "11. Send Message" << endl;
    cout << "12. Read Messages" << endl;
    cout << "0. Exit Game" << endl;
}

void Kingdom::handleChoice(int choice) {
    switch (choice) {
    case 1: {
        // Create social classes array without vector
        const int classCount = 3;
        SocialClass* classes[classCount] = {
            new Peasant(),
            new Merchant(),
            new Noble()
        };

        economy.collectTaxes(classes, classCount);

        // Clean up memory
        for (int i = 0; i < classCount; i++) {
            delete classes[i];
        }
        break;
    }
    case 2:
        military.recruitSoldiers(population, 10);
        break;
    case 3:
        military.trainArmy(3);
        break;
    case 4:
        military.fightBattle(military.armyStrength);
        break;
    case 5:
        bank.grantLoan(economy,500);
        break;
    case 6:
        resources.harvestFood(100);
        resources.harvestWood(50);
        break;
    case 7:
        leader.holdElection(economy);
        break;
    case 8:
        // Just pass the day
        break;
    case 9:
        handleRandomEvents();
        break;

    case 10: {
        char dir;
        cout << "Enter direction (N/S/E/W): ";
        cin >> dir;
        int newX = self.x, newY = self.y;
        switch (toupper(dir)) {
        case 'N': newY--; break;
        case 'S': newY++; break;
        case 'E': newX++; break;
        case 'W': newX--; break;
        default: cout << "Invalid direction!\n"; return;
        }
        if (!moveKingdom(newX, newY)) {
            cout << "Move failed! Position might be out of bounds or occupied.\n";
        }
        break;
    }
    case 11: {
        string receiver, content;
        cout << "Enter receiver kingdom name: ";
        cin.ignore();
        getline(cin, receiver);
        cout << "Enter message content: ";
        getline(cin, content);
        sendMessage(receiver, content);
        break;
    }
    case 12: {
        readMessages(self.name);
        break;
    }

    default:
        cout << "Invalid choice!\n";
    }

}
void Kingdom::updateGameState() {
    population.updatePopulation(10);
    military.checkMorale(resources.getFood(), economy.getTreasury());

    // Random events
    if (rand() % 5 == 0) {  // 20% chance of event
        events.triggerEvent(population, economy, military);
    }

    // Check for game over conditions
    if (population.getPopulation() <= 0 || economy.getTreasury() <= -1000) {
        cout << "GAME OVER! Your kingdom has fallen.";
        exit(0);
    }
}

void Kingdom::displayStatus() {
    cout << "Kingdom Status:";
    cout << " Population: " << population.getPopulation();
    cout << " Treasury: " << economy.getTreasury() << " gold";
    cout << " Army: " << military.getSoldierCount() << " soldiers";
    cout << " Food: " << resources.getFood() << " units";
    cout << " Leader: " << leader.getName() << " (" << leader.getApproval() << "% approval)";
}
void Kingdom::handleRandomEvents() {
    int eventChance = rand() % 10; // 0-9

    if (eventChance < 3) { // 30% chance of an event
        int eventType = rand() % 3; // 0=Famine, 1=War, 2=Plague

        switch (eventType) {
        case 0: // Famine
            food -= 100;
            cout << "DISASTER! Famine strikes! (-100 food)" << endl;
            break;
        case 1: // War
            gold -= 200;
            populations -= 20;
            cout << "DISASTER! War breaks out! (-200 gold, -20 people)" << endl;
            break;
        case 2: // Plague
            populations -= 50;
            cout << "DISASTER! Plague spreads! (-50 people)" << endl;
            break;
        }
    }
    else {
        cout << "Today was peaceful." << endl;
    }
}
void Kingdom::initializeMap() {
    for (int i = 0; i < MAP_SIZE; i++) {
        for (int j = 0; j < MAP_SIZE; j++) {
            mapGrid[i][j] = '.';
        }
    }
    mapGrid[self.y][self.x] = 'K';
}

void Kingdom::displayMap() const {
    cout << "\n=== Kingdom Map ===" << endl;
    cout << "+---------------------+" << endl;
    for (int y = 0; y < MAP_SIZE; y++) {
        cout << "| ";
        for (int x = 0; x < MAP_SIZE; x++) {
            if (x == self.x && y == self.y) {
                cout << "K  | ";
            }
            else {
                cout << ".. | ";
            }
        }
        cout << endl;
    }
    cout << "+---------------------+" << endl;
}

bool Kingdom::isPositionOccupied(int x, int y) const {
    return (x == self.x && y == self.y);
}

bool Kingdom::moveKingdom(int newX, int newY) {
    if (newX < 0 || newX >= MAP_SIZE || newY < 0 || newY >= MAP_SIZE) return false;
    if (isPositionOccupied(newX, newY)) return false;

    int oldX = self.x;
    int oldY = self.y;

    mapGrid[oldY][oldX] = '.';
    self.x = newX;
    self.y = newY;
    mapGrid[newY][newX] = 'K';

    logMovement(self.name, oldX, oldY, newX, newY);
    return true;
}

void Kingdom::logMovement(string name, int oldX, int oldY, int newX, int newY) {
    cout << name << " moved from (" << oldX << "," << oldY << ") to (" << newX << "," << newY << ")" << endl;
}
void Kingdom::sendMessage(const string& receiver, const string& content) {
    if (messageCount < MAX_MESSAGES) {
        messages[messageCount].sender = self.name;
        messages[messageCount].receiver = receiver;
        messages[messageCount].content = content;
        messageCount++;
        cout << "Message sent to " << receiver << "!\n";
    }
    else {
        cout << "Message box full! Cannot send more messages.\n";
    }
}
void Kingdom::readMessages(const string& receiverName) {
    cout << "\n=== Messages for " << receiverName << " ===\n";
    bool found = false;
    for (int i = 0; i < messageCount; i++) {
        if (messages[i].receiver == receiverName) {
            cout << "From: " << messages[i].sender << " - " << messages[i].content << endl;
            found = true;
        }
    }
    if (!found) {
        cout << "No messages.\n";
    }
}

bool Kingdom::checkGameOver() {
    if (gold <= 0) {
        cout << "You went bankrupt!" << endl;
        return true;
    }
    if (populations <= 0) {
        cout << "Everyone died!" << endl;
        return true;
    }
    if (food <= 0) {
        cout << "Starved to death!" << endl;
        return true;
    }
    return false; // Game continues
}
