#pragma once
#include "Population.h"
#include "Military.h"
#include "Economy.h"
#include "Bank.h"
#include "Leader.h"
#include "EventSystem.h"
#include "ResourceManagement.h"
#include "Peasant.h"
#include "Merchant.h"
#include "Noble.h"
using namespace std;

#define MAP_SIZE 5
#define MAX_KINGDOMS 5
#define MAX_MESSAGES 100

// Structure to store kingdom info
struct KingdomInfo {
    string name;
    int x, y;  // Coordinates on the map
};

// Structure to store messages
struct Message {
    string sender;
    string receiver;
    string content;
};

class Kingdom {
private:
    int gold;
    int food;
    int populations;
    bool isGameOver;
    int dayCount;

    Population population;
    Military military;
    Economy economy;
    Bank bank;
    Leader leader;
    EventSystem events;
    ResourceManager resources;
    void sendMessage(const string& receiver, const string& content);
    void readMessages(const string& receiverName);
    // Map & Movement
    KingdomInfo self;
    char mapGrid[MAP_SIZE][MAP_SIZE];
    // Track which kingdoms are allied
    bool alliances[MAX_KINGDOMS];

    // Communication System variables
    Message messages[MAX_MESSAGES];  // Store messages
    int messageCount;  // Total number of messages

    // Map & Movement functions
    void initializeMap();
    void displayMap() const;
    bool isPositionOccupied(int x, int y) const;
    bool moveKingdom(int newX, int newY);
    void logMovement(string name, int oldX, int oldY, int newX, int newY);

    // Communication System functions
    void sendMessage();
    void readMessages();

    // Game logic
    void showMenu();
    void handleChoice(int choice);
    void updateGameState();
    void displayStatus();
    void handleRandomEvents();
    bool checkGameOver();
    void trade();
public:
    Kingdom();
   
    void runSimulation();
   
     

};
