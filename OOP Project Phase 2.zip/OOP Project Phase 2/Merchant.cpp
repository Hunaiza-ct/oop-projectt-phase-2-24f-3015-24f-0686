#include "Merchant.h"

Merchant::Merchant() : SocialClass("Merchant", 15, 30) {
    happiness = 70;
}

void Merchant::payTax() {
    cout << "Merchant pays " << taxRate << "% tax in gold" << endl;
}

int Merchant::getInfluence() {
    return influence * 2;  // Merchants have double influence
}