#include "Peasant.h"

Peasant::Peasant() : SocialClass("Peasant", 20, 10) {
    happiness = 60;
}

void Peasant::payTax() {
    cout << "Peasant pays " << taxRate << "% tax in crops" << endl;
    happiness -= 5;
}

void Peasant::demandRights() {
    if (happiness < 30) {
        cout << "Peasants are protesting!" << endl;
    }
}