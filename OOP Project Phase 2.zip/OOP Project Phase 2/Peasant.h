#pragma once
#include "social.h"

class Peasant : public SocialClass {
public:
    Peasant();
    void payTax() override;
    void demandRights() override;
};
