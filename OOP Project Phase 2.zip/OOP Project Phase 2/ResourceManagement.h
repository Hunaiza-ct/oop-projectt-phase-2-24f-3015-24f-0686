#pragma once
#include <iostream>
using namespace std;

class Population;
class Military;

class ResourceManager {
private:
    int food;
    int wood;
    int iron;
    int stone;
    string embargoA, embargoB;

    bool isEmbargoed(string from, string to);
    bool smugglingSuccess();
    int getResourceByName(string name);
    void addResource(string name, int amount);
    bool consumeResource(string name, int amount);

public:
    ResourceManager();

    // Harvest
    void harvestFood(int amount);
    void harvestWood(int amount);
    void harvestIron(int amount);

    // Consume
    void consumeFood(int amount);
    void consumeWood(int amount);
    void consumeIron(int amount);

    // Trade

    bool tradeFoodForWood(int foodAmount, int woodAmount);
    bool tradeWoodForIron(int woodAmount, int ironAmount);
    void embargo(string player1, string player2);
    void trade(string from, string to, string resource, int amount, bool smuggle);

    // Events
    void handleDrought();
    void handleBumperCrop();

    // Getters
    int getFood() const;
    int getWood() const;
    int getIron() const;
    int getStone() const;

    void printResources() const;
};

