#include "Kingdom.h"
#include <iostream>
using namespace std;
int main() {
    Kingdom myKingdom;  // Creates a new kingdom with default values

    cout << "Welcome to StrongHold Kingdom Simulator!" << endl;
    cout << "Starting new game..." << endl;

    myKingdom.runSimulation();  // Starts the game loop

    system("pause");
}