#include "Population.h"

// Constructor
Population::Population() {
    totalPeople = 1000;
    happiness = 70;
    foodSupply = 500;
}

// Updates population based on conditions
void Population::updatePopulation(int h) {
    if (foodSupply >= totalPeople) {
        totalPeople += totalPeople * 0.05; // 5% growth
        happiness += h;
    }
    else {
        totalPeople -= totalPeople * 0.10; // 10% die
        happiness -= 15;
    }
    if (totalPeople < 0) totalPeople = 0;
}

// Calculates happiness level
void Population::calculateHappiness(int h) {
    if (foodSupply < totalPeople / 2) {
        happiness -= h;
    }
    happiness = max(0, min(100, happiness)); // Clamps to 0-100
}

// Checks for revolt
bool Population::triggerRevolt() {
    if (happiness < 30) {
        cout << "REVOLT! The people are angry!" << endl;
        return true;
    }
    return false;
}

// Getters
int Population::getPopulation() { return totalPeople; }
int Population::getHappiness() { return happiness; }

// Setters
void Population::setFoodSupply(int food) { foodSupply = food; }