#pragma once
#include <iostream>
using namespace std;

class Population {
private:
    int totalPeople;    // Current population count
    int happiness;      // 0-100 scale (100 = very happy)
    int foodSupply;     // Food available

public:
    Population();       // Constructor

    // Core functions
    void updatePopulation(int h);
    void calculateHappiness(int h);
    bool triggerRevolt();

    // Getters
    int getPopulation();
    int getHappiness();

    // Setters
    void setFoodSupply(int food);
};
